import "./Slogan.css"



function Slogan() {
    return (
        <div className="slogan">
            <div className="slogan_container">
                <div className="slogan_text">
                    Построение лучшего будущего посредством веб-разработки, мобильных приложений и дизайна
                </div>
            </div>
        </div>
    )
}


export default Slogan;